// Static place data with situational tags for the AI recommendation demo.
// Each place carries "fit" attributes so planEngine.js can score it against
// the user's stated intent (mood, budget, group size, duration).

export const places = [
  {
    id: "tatsuya",
    name: "Tatsuya Bookstore Café",
    category: "DerLg",
    image: "/assets/places/tatsuya.webp",
    priceLevel: 1, // 1=$, 2=$$, 3=$$$
    pricePerPerson: 3,
    tags: ["quiet", "wifi", "study", "chill", "indoor"],
    goodFor: { minGroup: 1, maxGroup: 4 },
    openUntil: "21:00",
    description: "Quiet reading nooks, reliable Wi-Fi, and strong iced coffee.",
  },
  {
    id: "funnifun",
    name: "Funnifun Arcade",
    category: "DerLg",
    image: "/assets/places/funnifun.webp",
    priceLevel: 2,
    pricePerPerson: 6,
    tags: ["group", "loud", "explore", "date", "indoor"],
    goodFor: { minGroup: 2, maxGroup: 8 },
    openUntil: "23:00",
    description: "Claw machines, racing games, and a photo booth corner.",
  },
  {
    id: "cocopark",
    name: "Coconut Park",
    category: "DerLg",
    image: "/assets/places/cocopark.webp",
    priceLevel: 1,
    pricePerPerson: 0,
    tags: ["outdoor", "group", "chill", "explore", "free"],
    goodFor: { minGroup: 1, maxGroup: 12 },
    openUntil: "22:00",
    description: "Riverside park, good for group hangouts and sunset walks.",
  },
  {
    id: "mimtes",
    name: "MiMtes Noodle House",
    category: "NhamEy",
    image: "/assets/places/mimtes.webp",
    priceLevel: 1,
    pricePerPerson: 4,
    tags: ["cheap", "group", "chill", "indoor"],
    goodFor: { minGroup: 1, maxGroup: 6 },
    openUntil: "22:00",
    description: "Affordable noodle soup, quick service, casual seating.",
  },
  {
    id: "kaixin",
    name: "Kaixin Dessert Bar",
    category: "NhamEy",
    image: "/assets/places/kaixin.webp",
    priceLevel: 2,
    pricePerPerson: 5,
    tags: ["date", "chill", "indoor", "explore"],
    goodFor: { minGroup: 1, maxGroup: 4 },
    openUntil: "23:30",
    description: "Dim lighting, plated desserts, good for a low-key date.",
  },
  {
    id: "sajkoang",
    name: "Saj Ko Ang BBQ",
    category: "NhamEy",
    image: "/assets/places/sajkoang.webp",
    priceLevel: 2,
    pricePerPerson: 7,
    tags: ["group", "loud", "explore", "indoor"],
    goodFor: { minGroup: 3, maxGroup: 10 },
    openUntil: "23:00",
    description: "Grill-your-own BBQ, built for bigger groups splitting a table.",
  },
];

// Mood chips shown in the UI. `tags` map a mood to place tags used for scoring.
export const moods = [
  { id: "study", label: "Study", emoji: "📚", tags: ["quiet", "wifi", "study"] },
  { id: "chill", label: "Chill", emoji: "☕", tags: ["chill", "indoor", "outdoor"] },
  { id: "explore", label: "Explore", emoji: "🧭", tags: ["explore", "outdoor"] },
  { id: "date", label: "Date", emoji: "🌙", tags: ["date", "chill"] },
  { id: "group", label: "Group hangout", emoji: "👥", tags: ["group", "loud"] },
];
