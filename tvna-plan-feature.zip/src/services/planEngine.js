import { places, moods } from "./mockData";

/**
 * generatePlan(intent) -> { steps, summary, matchScore }
 *
 * intent = {
 *   budgetPerPerson: number,
 *   groupSize: number,
 *   durationHours: number,
 *   moodId: string,        // one of moods[].id
 * }
 *
 * This is intentionally NOT calling a real LLM. It's a rule-based scorer
 * that mimics what an AI recommendation would return, so the UI/UX can be
 * fully demoed today. Swap the body of this function for a real API call
 * later without touching any component code.
 */
export function generatePlan(intent) {
  const mood = moods.find((m) => m.id === intent.moodId) ?? moods[0];

  const scored = places
    .filter((p) => intent.groupSize >= p.goodFor.minGroup && intent.groupSize <= p.goodFor.maxGroup)
    .map((p) => {
      let score = 0;
      const reasons = [];

      // Mood/tag overlap
      const overlap = p.tags.filter((t) => mood.tags.includes(t));
      score += overlap.length * 20;
      if (overlap.length) reasons.push(`Fits your "${mood.label}" mood`);

      // Budget fit
      if (p.pricePerPerson <= intent.budgetPerPerson) {
        score += 25;
        reasons.push(
          p.pricePerPerson === 0
            ? "Free"
            : `$${p.pricePerPerson}/person, within your $${intent.budgetPerPerson} budget`
        );
      } else {
        score -= 15;
      }

      // Group size fit
      score += 10;
      reasons.push(`Works for a group of ${intent.groupSize}`);

      return { ...p, score: Math.max(0, Math.min(100, score)), reasons };
    })
    .sort((a, b) => b.score - a.score);

  // Build a simple 3-stop itinerary: activity -> food -> chill, picking the
  // top-scoring place per category, falling back gracefully if one category
  // has no candidates left.
  const byCategory = (cat) => scored.filter((p) => p.category === cat);
  const activity = byCategory("DerLg")[0];
  const food = byCategory("NhamEy")[0];
  const secondActivity = byCategory("DerLg")[1];

  const stepDefs = [activity, food, secondActivity].filter(Boolean);

  const startHour = 16; // 4pm demo default
  const stepDurationHrs = intent.durationHours / Math.max(stepDefs.length, 1);

  const steps = stepDefs.map((place, i) => {
    const hour = Math.floor(startHour + i * stepDurationHrs);
    const minute = Math.round((startHour + i * stepDurationHrs - hour) * 60);
    const time = `${String(hour % 24).padStart(2, "0")}:${String(minute).padStart(2, "0")}`;
    return {
      time,
      place,
      matchScore: place.score,
      reasons: place.reasons,
    };
  });

  const totalCost = steps.reduce((sum, s) => sum + s.place.pricePerPerson, 0);
  const avgMatch = Math.round(steps.reduce((sum, s) => sum + s.matchScore, 0) / Math.max(steps.length, 1));

  return {
    mood,
    steps,
    summary: {
      totalCostPerPerson: totalCost,
      estimatedMatch: avgMatch,
      groupSize: intent.groupSize,
      durationHours: intent.durationHours,
    },
  };
}
