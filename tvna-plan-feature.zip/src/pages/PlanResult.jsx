import { useState, useCallback } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import AIThinkingState from "../components/plan/AIThinkingState";
import ItineraryTimeline from "../components/plan/ItineraryTimeline";
import { generatePlan } from "../services/planEngine";

export default function PlanResult() {
  const { state } = useLocation();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [plan, setPlan] = useState(null);

  const intent = state?.intent;

  const handleDone = useCallback(() => {
    setPlan(generatePlan(intent));
    setLoading(false);
  }, [intent]);

  if (!intent) {
    return (
      <section className="flex flex-col items-center px-6 py-16 gap-4">
        <p>No plan request found.</p>
        <button
          onClick={() => navigate("/plan")}
          className="rounded-full bg-[#741EFF] text-white px-6 py-2 font-semibold"
        >
          Start a plan
        </button>
      </section>
    );
  }

  return (
    <section className="flex flex-col items-center px-6 py-16">
      {loading ? (
        <AIThinkingState onDone={handleDone} />
      ) : (
        <>
          <h1 className="text-2xl font-bold mb-6 text-center">Here's your plan</h1>
          <ItineraryTimeline plan={plan} />
          <div className="mt-8 flex gap-3">
            <button
              onClick={() => navigate("/plan")}
              className="rounded-full border border-gray-300 dark:border-neutral-700 px-6 py-2 font-medium"
            >
              Adjust
            </button>
            <button className="rounded-full bg-[#741EFF] text-white px-6 py-2 font-semibold">
              Let's go
            </button>
          </div>
        </>
      )}
    </section>
  );
}
