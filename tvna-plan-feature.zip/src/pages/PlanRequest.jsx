import { useNavigate } from "react-router-dom";
import IntentForm from "../components/plan/IntentForm";

export default function PlanRequest() {
  const navigate = useNavigate();

  function handleSubmit(intent) {
    navigate("/plan/result", { state: { intent } });
  }

  return (
    <section className="flex flex-col items-center px-6 py-16">
      <h1 className="text-2xl font-bold mb-2 text-center">What should we do?</h1>
      <p className="text-[color:var(--text-muted,#6b7280)] mb-8 text-center max-w-sm">
        Tell TvNa your vibe. We'll turn it into a plan you can just go do.
      </p>
      <IntentForm onSubmit={handleSubmit} />
    </section>
  );
}
