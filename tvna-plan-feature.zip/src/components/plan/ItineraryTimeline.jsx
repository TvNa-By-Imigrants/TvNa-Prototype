export default function ItineraryTimeline({ plan }) {
  const { steps, summary, mood } = plan;

  return (
    <div className="w-full max-w-lg">
      <div className="mb-6 flex items-center justify-between rounded-xl bg-[color:var(--card-bg,#f3f4f6)] px-4 py-3">
        <div>
          <p className="text-xs text-[color:var(--text-muted,#6b7280)]">Mood</p>
          <p className="font-semibold">{mood.emoji} {mood.label}</p>
        </div>
        <div className="text-right">
          <p className="text-xs text-[color:var(--text-muted,#6b7280)]">Est. total</p>
          <p className="font-semibold">${summary.totalCostPerPerson}/person</p>
        </div>
        <div className="text-right">
          <p className="text-xs text-[color:var(--text-muted,#6b7280)]">Match</p>
          <p className="font-semibold text-[#741EFF]">{summary.estimatedMatch}%</p>
        </div>
      </div>

      <ol className="relative border-l-2 border-[#741EFF]/30 pl-6 flex flex-col gap-8">
        {steps.map((step, i) => (
          <li key={step.place.id} className="relative">
            <span className="absolute -left-[31px] top-1 h-3 w-3 rounded-full bg-[#741EFF]" />
            <p className="text-xs font-mono text-[color:var(--text-muted,#6b7280)] mb-1">{step.time}</p>
            <div className="flex gap-3 rounded-xl bg-[color:var(--card-bg,#f3f4f6)] p-3">
              <img
                src={step.place.image}
                alt={step.place.name}
                className="h-16 w-16 rounded-lg object-cover flex-shrink-0 bg-gray-200"
                onError={(e) => (e.currentTarget.style.visibility = "hidden")}
              />
              <div className="min-w-0">
                <p className="font-semibold truncate">{step.place.name}</p>
                <p className="text-sm text-[color:var(--text-muted,#6b7280)] line-clamp-2">
                  {step.place.description}
                </p>
                <p className="mt-1 text-xs text-[#741EFF]">
                  {step.matchScore}% match — {step.reasons[0]}
                </p>
              </div>
            </div>
          </li>
        ))}
      </ol>
    </div>
  );
}
