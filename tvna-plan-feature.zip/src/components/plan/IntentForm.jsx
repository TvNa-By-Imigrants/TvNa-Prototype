import { useState } from "react";
import MoodSelector from "./MoodSelector";

export default function IntentForm({ onSubmit }) {
  const [budgetPerPerson, setBudgetPerPerson] = useState(10);
  const [groupSize, setGroupSize] = useState(3);
  const [durationHours, setDurationHours] = useState(4);
  const [moodId, setMoodId] = useState("chill");

  function handleSubmit(e) {
    e.preventDefault();
    onSubmit({ budgetPerPerson, groupSize, durationHours, moodId });
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-6 max-w-md w-full">
      <div>
        <label className="block text-sm font-medium mb-2">What's the mood?</label>
        <MoodSelector value={moodId} onChange={setMoodId} />
      </div>

      <div>
        <label htmlFor="budget" className="block text-sm font-medium mb-2">
          Budget per person: <span className="text-[#741EFF] font-semibold">${budgetPerPerson}</span>
        </label>
        <input
          id="budget"
          type="range"
          min={0}
          max={30}
          step={1}
          value={budgetPerPerson}
          onChange={(e) => setBudgetPerPerson(Number(e.target.value))}
          className="w-full accent-[#741EFF]"
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label htmlFor="group" className="block text-sm font-medium mb-2">
            Group size
          </label>
          <input
            id="group"
            type="number"
            min={1}
            max={12}
            value={groupSize}
            onChange={(e) => setGroupSize(Number(e.target.value))}
            className="w-full rounded-lg border border-gray-300 dark:border-neutral-700 bg-transparent px-3 py-2"
          />
        </div>
        <div>
          <label htmlFor="duration" className="block text-sm font-medium mb-2">
            Hours you have
          </label>
          <input
            id="duration"
            type="number"
            min={1}
            max={12}
            value={durationHours}
            onChange={(e) => setDurationHours(Number(e.target.value))}
            className="w-full rounded-lg border border-gray-300 dark:border-neutral-700 bg-transparent px-3 py-2"
          />
        </div>
      </div>

      <button
        type="submit"
        className="mt-2 rounded-full bg-[#741EFF] text-white font-semibold py-3 hover:brightness-110 active:scale-95 transition-transform duration-150"
      >
        Plan my day
      </button>
    </form>
  );
}
