import { moods } from "../../services/mockData";

export default function MoodSelector({ value, onChange }) {
  return (
    <div className="flex flex-wrap gap-2">
      {moods.map((mood) => {
        const active = value === mood.id;
        return (
          <button
            key={mood.id}
            type="button"
            onClick={() => onChange(mood.id)}
            className={[
              "flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium transition-colors duration-200 border",
              active
                ? "bg-[#741EFF] text-white border-[#741EFF]"
                : "bg-transparent text-[color:var(--text-muted,#6b7280)] border-gray-300 dark:border-neutral-700 hover:border-[#741EFF] hover:text-[#741EFF]",
            ].join(" ")}
          >
            <span aria-hidden="true">{mood.emoji}</span>
            {mood.label}
          </button>
        );
      })}
    </div>
  );
}
