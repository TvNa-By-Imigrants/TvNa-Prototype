import { useEffect, useState } from "react";

const STEPS = [
  "Reading your intent...",
  "Matching places to your mood...",
  "Checking budget and group fit...",
  "Building your itinerary...",
];

/**
 * Purely cosmetic. Cycles through STEPS on an interval, then calls
 * onDone() after `totalMs`. Gives the impression of AI inference
 * happening without needing a real backend call.
 */
export default function AIThinkingState({ totalMs = 1800, onDone }) {
  const [stepIndex, setStepIndex] = useState(0);

  useEffect(() => {
    const stepMs = totalMs / STEPS.length;
    const interval = setInterval(() => {
      setStepIndex((i) => Math.min(i + 1, STEPS.length - 1));
    }, stepMs);
    const timeout = setTimeout(() => onDone?.(), totalMs);
    return () => {
      clearInterval(interval);
      clearTimeout(timeout);
    };
  }, [totalMs, onDone]);

  return (
    <div className="flex flex-col items-center justify-center gap-4 py-16">
      <div className="h-10 w-10 rounded-full border-2 border-[#741EFF] border-t-transparent animate-spin" />
      <p className="text-sm text-[color:var(--text-muted,#6b7280)] transition-opacity duration-300">
        {STEPS[stepIndex]}
      </p>
    </div>
  );
}
